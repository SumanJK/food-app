function navbar() {
  return `<div id="navbar">
    <div id="searchBar">
        <div id="icon">
        <a href="index.html"><img src="https://www.themealdb.com/images/logo-small.png" alt=""></a>
        
        </div>
        <input type="text" id="searchTerm" oninput="showCancel()" placeholder="Search">
        <div id="button"></div>
        <button id="searchButton" ><i class="fa-solid fa-magnifying-glass"></i></button>
        <a href="random.html">random</a>
        <a href="trending.html">trending</a>
    </div>
</div>`;
}

export default navbar;
